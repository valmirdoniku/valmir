![GitHub](https://img.shields.io/github/license/PuneethReddyHC/online-shopping-system-advanced)

<a href="https://www.buymeacoffee.com/PuneethReddyHC" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" width="195" height="55"></a>

> ### Any DBMS OR WEB TECHNOLOGIES (php, django, angular or react) or MachineLearning projects with installation support and code explaination for Premium contact phone: +919535688928 gmail: puneethreddy951@gmail.com

# Event-site
helps to register an users for on events conducted in college fests with simple logic with secured way

# Installation

1. Install XAMPP or WAMPP.

2. Open XAMPP Control panal and start [apache] and [mysql] .

3. Download project from github(https://github.com/PuneethReddyHC/event-management.git)  
    OR follow gitbash commands
    
    i>cd C:\\xampp\htdocs\
    
    ii>git clone https://github.com/PuneethReddyHC/event-management.git
    
4. extract files in C:\\xampp\htdocs\.

5. open link localhost/phpmyadmin

6. click on new at side navbar.

7. give a database name as (eventsite) hit on create button.

8. after creating database name click on import.

9. browse the file in directory[event-management/database/events.sql].

10. after importing successfully.

11. open any browser and type http://localhost/event-management-master.

12. first register and then login

13. admin login details  Email=admin@gmail.com and Password=123456789.

## If you like my project 
Bye me Cup of coffee

### Google pay or phonepay number 9535688928

## visit my other repository with different admin pages with below link
https://github.com/PuneethReddyHC/online-shopping-system-with-advanced-admin-page

https://github.com/PuneethReddyHC/online-shopping-system-advanced

## Screenshots
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/home.png)
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/events.png)
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/about.png)
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/events1.png)
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/login.png)

##  If you like my project hit a star button
